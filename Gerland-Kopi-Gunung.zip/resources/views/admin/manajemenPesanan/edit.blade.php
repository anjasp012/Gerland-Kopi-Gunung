<form action="{{ route('pesanan.update', $pesanan->kode_pesanan) }}" method="POST">
    @csrf
    @method('put')
    <select name="status" id="status" class="form-select">
        @foreach ($status as $item)
            <option value="{{ $item->id }}">{{ $item->name }}</option>
        @endforeach
    </select>

    <button type="submit">simpan</button>
</form>
