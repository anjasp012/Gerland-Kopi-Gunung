@if (Route::is('makanan.edit'))
    Edit Makanan
@else
    Edit Minuman
@endif

<input type="text" value="{{ $menu->name }}">
<input type="text" value="{{ $menu->gambar }}">
<input type="text" value="{{ $menu->harga }}">