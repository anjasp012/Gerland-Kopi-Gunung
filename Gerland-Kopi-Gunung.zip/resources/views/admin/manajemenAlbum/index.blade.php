@extends('admin.layouts.app')
@section('content')
    Ini Albumm
@endsection
