@extends('admin.layouts.app')
@section('content')
    {{ $user->name }}
    {{ $user->email }}
@endsection
