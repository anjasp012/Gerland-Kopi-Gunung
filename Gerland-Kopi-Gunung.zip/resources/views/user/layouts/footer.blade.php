<footer class="bg-black py-5">
    <div class="container">
        <div class="row">
            <div class="col-8">
                <h3 class="text-white" style="font-weight: bold">Gerland Kopi Gunung</h3>
            </div>
            <div class="col-2 ">
                <ul class="text-white" style="list-style: none">
                    <li>Service</li>
                    <li>Email</li>
                    <li>Campaign</li>
                    <li>Branding</li>
                    <li>Offline</li>
                </ul>
            </div>
            <div class="col-2 ">
                <ul class="text-white" style="list-style: none">
                    <li>About</li>
                    <li>Our Story</li>
                    <li>Benefit</li>
                    <li>Team</li>
                    <li>Careers</li>
                </ul>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-6">
            </div>
            <div class="col-6">
                <div class="d-flex justify-content-end">

                </div>
            </div>
        </div>
    </div>
</footer>
